Restaurant Management Website/menu/reservation/order/payment/inventory/staff

How to run:
1. Install Xampp server and start MYSQL and Apache.
2. Open phpmyadmin/localhost in your local browser.
3. Create a database with name given in 01 LOGIN DETAILS & PROJECT INFO file and import the sql file.
4. Type https://localhost/RestaurantPOS_Group27 in the web browser to run.


